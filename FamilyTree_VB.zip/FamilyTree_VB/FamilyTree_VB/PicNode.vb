﻿Imports FamilyTree_VB

Public Class PicNode
    Implements IDrawable

    Public Pic As Image = Nothing

    Public Desc As String

    Public Sel As Boolean = False

    Public Sub New(ByVal desc As String, ByVal pic As Image)

        desc = desc
        pic = pic

    End Sub

    Public NodeSize As SizeF = New SizeF(100, 100)

    Public Function GetSize(ByVal gr As Graphics, ByVal fFont As Font) As SizeF

        Return NodeSize

    End Function

    Private Function Loc(ByVal ptCentre As PointF) As RectangleF

        Return New RectangleF(ptCentre.X - NodeSize.Width / 2, ptCentre.Y - NodeSize.Height / 2, NodeSize.Width, NodeSize.Height)

    End Function

    Public Function Point(ByVal gr As Graphics, ByVal font As Font, ByVal ptCentre As PointF, ByVal ptTarget As PointF) As Boolean

        Dim rect As RectangleF = Loc(ptCentre)

        Return rect.Contains(ptTarget)

    End Function


    Public Sub Draw(ByVal x As Single, ByVal y As Single, ByVal gr As Graphics, ByVal pen As Pen, ByVal backbrush As Brush, ByVal brush As Brush, ByVal font As Font)

        Dim locrec As RectangleF = Loc(New PointF(x, y))

        Dim rect As Rectangle = Rectangle.Round(locrec)

        If Sel Then

            gr.FillRectangle(Brushes.White, rect)
            ControlPaint.DrawBorder3D(gr, rect, Border3DStyle.Sunken)

        Else

            gr.FillRectangle(Brushes.Orange, rect)
            ControlPaint.DrawBorder3D(gr, rect, Border3DStyle.Raised)

        End If

        locrec.Inflate(-5, -5)
        locrec = Position(Pic, locrec)
        gr.DrawImage(Pic, locrec)

    End Sub

    Private Function Position(pic As Image, rect As RectangleF) As RectangleF

        Dim fWidth As Single = pic.Width
        Dim fHeight As Single = pic.Height

        Dim fCentre As Single = fWidth / fHeight
        Dim fRecCentre As Single = rect.Width / rect.Height
        Dim scale As Single = 1

        If fCentre > fRecCentre Then

            scale = rect.Width / fWidth

        Else

            scale = rect.Height / fHeight

        End If

        fWidth *= scale
        fHeight *= scale

        Dim drawing_rect As RectangleF = New RectangleF(rect.X + (rect.Width - fWidth) / 2, rect.Y + (rect.Height - fHeight) / 2, fWidth, fHeight)

        Return drawing_rect

    End Function

    Private Function IDrawable_GetSize(gr As Graphics, fFont As Font) As SizeF Implements IDrawable.GetSize

        Throw New NotImplementedException()

    End Function

    Private Function IDrawable_Point(gr As Graphics, fFont As Font, ptCentre As PointF, ptTarget As PointF) As Boolean Implements IDrawable.Point

        Throw New NotImplementedException()

    End Function

    Private Sub IDrawable_Draw(x As Single, y As Single, gr As Graphics, pen As Pen, BackBrush As Brush, Brush As Brush, fFont As Font) Implements IDrawable.Draw

        Throw New NotImplementedException()

    End Sub

End Class
