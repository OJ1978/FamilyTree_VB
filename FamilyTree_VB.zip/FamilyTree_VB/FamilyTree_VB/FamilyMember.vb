﻿
Imports System.Collections.Generic
Imports System.Drawing

Class FamilyMember(Of T As IDrawable)

    Public Obj As T

    Public lstChildren As List(Of FamilyMember(Of T)) = New List(Of FamilyMember(Of T))()

    Private Const fX As Single = 5

    Private Const fY As Single = 30

    Private ptCenter As PointF

    Public fFont As Font = Nothing

    Public pPen As Pen = Pens.Black

    Public bBrush As Brush = Brushes.Red

    Public bBackBrush As Brush = Brushes.White

    Public Sub New(ByVal obj As T)

        obj = obj

    End Sub

    Public Sub New(ByVal obj As T, ByVal fFont As Font)

        obj = obj
        Me.fFont = fFont

    End Sub

    Public Sub Add(ByVal obj As FamilyMember(Of T))

        lstChildren.Add(obj)

    End Sub

    Public Sub Organize(ByVal gr As Graphics, ByRef X As Single, ByRef Y As Single)

        Dim szObj As SizeF = Obj.GetSize(gr, fFont)
        Dim xX As Single = X

        Dim MaxY As Single = Y + szObj.Height
        Dim SubY As Single = Y + szObj.Height + fY

        For Each tChild As FamilyMember(Of T) In lstChildren

            Dim MinY As Single = SubY

            tChild.Organize(gr, X, MinY)

            If MaxY < MinY Then MaxY = MinY

            xX += fX

        Next

        If lstChildren.Count > 0 Then xX -= fX

        Dim SubWidth As Single = xX - xX

        If szObj.Width > SubWidth Then

            xX = xX + (szObj.Width - SubWidth) / 2

            For Each tChild As FamilyMember(Of T) In lstChildren

                tChild.Organize(gr, xX, SubY)
                xX += fX

            Next

            SubWidth = szObj.Width

        End If

        ptCenter = New PointF(xX + SubWidth / 2, Y + szObj.Height / 2)

        xX += SubWidth
        Y = MaxY

    End Sub

    Public Sub DrawFamily(ByVal gr As Graphics, ByRef x As Single, ByVal y As Single)

        Organize(gr, x, y)
        DrawFamily(gr)

    End Sub

    Public Sub DrawFamily(ByVal gr As Graphics)

        DrawLinks(gr)
        DrawNodes(gr)

    End Sub

    Private Sub DrawLinks(ByVal gr As Graphics)

        If lstChildren.Count = 1 Then

            gr.DrawLine(pPen, ptCenter, lstChildren(0).ptCenter)

        ElseIf lstChildren.Count > 1 Then

            Dim xmin As Single = lstChildren(0).ptCenter.X
            Dim xmax As Single = lstChildren(lstChildren.Count - 1).ptCenter.X
            Dim my_size As SizeF = Obj.GetSize(gr, fFont)
            Dim y As Single = ptCenter.Y + my_size.Height / 2 + fY / 2.0F

            gr.DrawLine(pPen, xmin, y, xmax, y)
            gr.DrawLine(pPen, ptCenter.X, ptCenter.Y, ptCenter.X, y)

            For Each tChild As FamilyMember(Of T) In lstChildren

                gr.DrawLine(pPen, tChild.ptCenter.X, y, tChild.ptCenter.X, tChild.ptCenter.Y)

            Next

        End If

        For Each tChild As FamilyMember(Of T) In lstChildren

            tChild.DrawLinks(gr)

        Next

    End Sub

    Private Sub DrawNodes(ByVal gr As Graphics)

        Obj.Draw(ptCenter.X, ptCenter.Y, gr, pPen, bBackBrush, bBrush, fFont)

        For Each tChild As FamilyMember(Of T) In lstChildren

            tChild.DrawNodes(gr)

        Next

    End Sub

    Public Function NodePoint(ByVal gr As Graphics, ByVal ptTarget As PointF) As FamilyMember(Of T)

        If Obj.Point(gr, fFont, ptCenter, ptTarget) Then Return Me

        For Each tChild As FamilyMember(Of T) In lstChildren

            Dim hit_node As FamilyMember(Of T) = tChild.NodePoint(gr, ptTarget)

            If hit_node IsNot Nothing Then Return hit_node

        Next

        Return Nothing

    End Function

    Public Function Delete(ByVal tTarget As FamilyMember(Of T)) As Boolean

        For Each tChild As FamilyMember(Of T) In lstChildren

            If tChild.Equals(tTarget) Then

                lstChildren.Remove(tChild)

                Return True

            End If

            If tChild.Delete(tTarget) Then Return True

        Next

        Return False
    End Function
End Class
