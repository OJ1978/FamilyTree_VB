﻿
Imports System.Drawing

Interface IDrawable

    Function GetSize(ByVal gr As Graphics, ByVal fFont As Font) As SizeF

    Function Point(ByVal gr As Graphics, ByVal fFont As Font, ByVal ptCentre As PointF, ByVal ptTarget As PointF) As Boolean

    Sub Draw(ByVal x As Single, ByVal y As Single, ByVal gr As Graphics, ByVal pen As Pen, ByVal BackBrush As Brush, ByVal Brush As Brush, ByVal fFont As Font)

End Interface
