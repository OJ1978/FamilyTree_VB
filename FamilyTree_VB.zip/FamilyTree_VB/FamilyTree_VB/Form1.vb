﻿
Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Text
Imports System.Windows.Forms


Partial Public Class Form1
    Inherits Form

    Private SelectedNode As FamilyMember(Of PicNode)

    Private Sub ShowTree()

        Using gr As Graphics = picFamily.CreateGraphics()

            Dim xmin As Single = 0, ymin As Single = 0

            Unknown.Organize(gr, xmin, ymin)
            'HetepheresI.Organize(gr, xmin, ymin)'
            'SNEFERU.Organize(gr, xmin, ymin)'

            xmin = (Me.ClientSize.Width - xmin) / 2
            ymin = 10
            Unknown.Organize(gr, xmin, ymin)

        End Using

        picFamily.Refresh()

    End Sub

    Private Sub SelNode(ByVal pt As PointF)

        If SelectedNode IsNot Nothing Then

            SelectedNode.Obj.Sel = False
            lblNodeText.Text = ""

        End If

        Using gr As Graphics = picFamily.CreateGraphics()

            SelectedNode = HetepheresI.NodePoint(gr, pt)

        End Using

        If SelectedNode IsNot Nothing Then

            SelectedNode.Obj.Sel = True
            lblNodeText.Text = SelectedNode.Obj.Desc

        End If

        picFamily.Refresh()

    End Sub

    Private HetepheresI As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("HetepheresI", My.Resources.Hetepheres_I))

    Private SNEFERU As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("SNEFERU", My.Resources.SNEFERU))

    Private Unknown As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Unknown", My.Resources.Unknown))

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs)

        Dim MerititesI As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("MerititesI", My.Resources.Meritites_I))
        Dim KHUFU As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("KHUFU", My.Resources.KHUFU))
        Dim Henutsen As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Henutsen", My.Resources.Henutsen))
        Dim Rahotep As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Rahotep", My.Resources.Rahotep))
        Dim NefermaatI As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("NefermaatI", My.Resources.Nefermaat_I))
        Dim Itet As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Itet", My.Resources.Itet))
        Dim Djedefhor As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Djedefhor", My.Resources.Djedefhor))
        Dim Kawab As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Kawab", My.Resources.Kawab))
        Dim HetepheresII As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("HetepheresII", My.Resources.Hetepheres_II))
        Dim DJEDEFRE As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("DJEDEFRE", My.Resources.DJEDEFRE))
        Dim Khentetka As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Khentetka", My.Resources.Khentetka))
        Dim KHAFRE As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("KHAFRE", My.Resources.KHAFRE))
        Dim KhamerernebtyI As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("KhamerernebtyI", My.Resources.Khamerernebty_I))
        Dim Hemiunu As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Hemiunu", My.Resources.Hemiunu))
        Dim MeresankhII As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("MeresankhII", My.Resources.Meresankh_II))
        Dim Setka As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Setka", My.Resources.Setka))
        Dim Hernet As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Hernet", My.Resources.Hernet))
        Dim MeresankhIII As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("MeresankhIII", My.Resources.Meresankh_III))
        Dim MENKAURA As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("MENKAURA", My.Resources.MENKAURA))
        Dim KhamerernebtyII As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("KhamerernebtyII", My.Resources.Khamerernebty_II))
        Dim Baka As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Baka", My.Resources.Baka))
        Dim Neferhetepes As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Neferhetepes", My.Resources.Neferhetepes))
        Dim SHEPSESKAF As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("SHEPSESKAF", My.Resources.SHEPSESKAF))
        Dim Bunefer As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Bunefer", My.Resources.Bunefer))
        Dim Djedefptah As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Djedefptah", My.Resources.Djedefptah))
        Dim Khamaat As FamilyMember(Of PicNode) = New FamilyMember(Of PicNode)(New PicNode("Khamaat", My.Resources.Khamaat))

        HetepheresI.Add(MerititesI)
        HetepheresI.Add(KHUFU)
        HetepheresI.Add(Henutsen)
        Unknown.Add(Rahotep)
        Unknown.Add(NefermaatI)
        Unknown.Add(Itet)
        MerititesI.Add(Djedefhor)
        MerititesI.Add(Kawab)
        KHUFU.Add(HetepheresII)
        KHUFU.Add(DJEDEFRE)
        KHUFU.Add(Khentetka)
        KHUFU.Add(KHAFRE)
        KHUFU.Add(KhamerernebtyI)
        NefermaatI.Add(Hemiunu)
        Djedefhor.Add(MeresankhII)
        DJEDEFRE.Add(Setka)
        DJEDEFRE.Add(Hernet)
        DJEDEFRE.Add(MeresankhIII)
        DJEDEFRE.Add(MENKAURA)
        DJEDEFRE.Add(KhamerernebtyII)
        Setka.Add(Baka)
        Setka.Add(Neferhetepes)
        MENKAURA.Add(SHEPSESKAF)
        MENKAURA.Add(Bunefer)
        SHEPSESKAF.Add(Djedefptah)
        SHEPSESKAF.Add(Khamaat)

        ShowTree()

    End Sub

    Private Sub picFamily_Paint(ByVal sender As Object, ByVal e As PaintEventArgs)

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias
        e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit

        Unknown.DrawFamily(e.Graphics)

        'HetepheresI.DrawFamily(e.Graphics)'
        'SNEFERU.DrawFamily(e.Graphics)'

    End Sub

    Private Sub picFamily_MouseClick(ByVal sender As Object, ByVal e As MouseEventArgs)

        SelNode(e.Location)

    End Sub

End Class


