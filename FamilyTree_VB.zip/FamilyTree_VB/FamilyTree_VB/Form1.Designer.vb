﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picFamily = New System.Windows.Forms.PictureBox()
        Me.statusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblNodeText = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.picFamily, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.statusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'picFamily
        '
        Me.picFamily.BackColor = System.Drawing.SystemColors.Control
        Me.picFamily.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picFamily.Location = New System.Drawing.Point(0, 0)
        Me.picFamily.Name = "picFamily"
        Me.picFamily.Size = New System.Drawing.Size(784, 389)
        Me.picFamily.TabIndex = 12
        Me.picFamily.TabStop = False
        '
        'statusStrip1
        '
        Me.statusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblNodeText})
        Me.statusStrip1.Location = New System.Drawing.Point(0, 389)
        Me.statusStrip1.Name = "statusStrip1"
        Me.statusStrip1.Size = New System.Drawing.Size(784, 22)
        Me.statusStrip1.TabIndex = 11
        Me.statusStrip1.Text = "statusStrip1"
        '
        'lblNodeText
        '
        Me.lblNodeText.Name = "lblNodeText"
        Me.lblNodeText.Size = New System.Drawing.Size(0, 17)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 411)
        Me.Controls.Add(Me.picFamily)
        Me.Controls.Add(Me.statusStrip1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.picFamily, System.ComponentModel.ISupportInitialize).EndInit()
        Me.statusStrip1.ResumeLayout(False)
        Me.statusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents picFamily As PictureBox
    Private WithEvents statusStrip1 As StatusStrip
    Private WithEvents lblNodeText As ToolStripStatusLabel
End Class
